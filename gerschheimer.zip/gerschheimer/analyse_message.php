<?php
// fichier JSON TF-IDF
$score_map_file = "scripts/python/score_map.json";

// Vérif chemin
if (!file_exists($score_map_file)) {
    echo json_encode(["error" => "Fichier ScoreMap introuvable."]);
    exit;
}


$score_map = json_decode(file_get_contents($score_map_file), true);

$input = json_decode(file_get_contents('php://input'), true);
if (!isset($input['message'])) {
    echo json_encode(["error" => "Aucun message envoyé."]);
    exit;
}
$message = $input['message'];



// mots ignorés
$stop_words = ["the", "and", "a", "in", "of", "to", ",", ".", "is", "it", "this", "on", "at", "as"];

// Diviser le message en mots
$words = preg_split('/\s+/', $message);
$score_total = 0;
$word_scores = []; // scores de chaque mot

// score total du message
foreach ($words as $word) {
    $word = strtolower(trim($word)); // Convertir minuscule+nettoyer les espaces
    $word = preg_replace('/[^a-z0-9]+/', '', $word); // Supprimer ponctuation

    // Ignorer mots vides
    if (in_array($word, $stop_words)) {
        continue;
    }

    // score mot
    if (isset($score_map[$word])) {
        $score = $score_map[$word];
        $score_total += $score;
        $word_scores[$word] = $score; 
    } else {
        $word_scores[$word] = 0; // Mots inconnus
    }
}


$threshold = 0; // seuil

// Retourner le résultat
if ($score_total < $threshold) {
    echo json_encode([
        "status" => "error",
        "message" => "Votre message a été bloqué car il contient du contenu offensant.",
        "details" => [
            "message" => $message,
            "total_score" => $score_total,
            "word_scores" => $word_scores
        ]
    ]);
} else {
    echo json_encode([
        "status" => "success",
        "message" => "Message accepté.",
        "details" => [
            "message" => $message,
            "total_score" => $score_total,
            "word_scores" => $word_scores
        ]
    ]);
}
