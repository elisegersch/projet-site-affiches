<?php
session_start();
require_once 'bd.php';

header('Content-Type: application/json');


if (!isset($_SESSION['client'])) {
    echo json_encode([]);
    exit;
}

try {
    $bd = getBD();
    $stmt = $bd->prepare('
        SELECT Clients.prenom, Messages.message
        FROM Messages
        JOIN Clients ON Messages.user_id = Clients.id_client
        WHERE Messages.created_at >= NOW() - INTERVAL 10 MINUTE
        ORDER BY Messages.created_at DESC
    ');
    $stmt->execute();
    $result = $stmt->get_result();

    $messages = [];
    while ($row = $result->fetch_assoc()) {
        $messages[] = [
            'user' => htmlspecialchars($row['prenom']),
            'message' => htmlspecialchars($row['message'])
        ];
    }

    echo json_encode($messages);
} catch (Exception $e) {
    echo json_encode([]);
}
?>
