<?php
require_once 'bd.php';
session_start();

// Vérification connexion
if (!isset($_SESSION['client'])) {
    header("Location: connexion.php");
    exit();
}

// Vérification Token
if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    echo 'CSRF token invalide.';
    exit();
}

// vérifier stock dispo
function verifierStockDisponible($id_art, $quantite, $conn) {
    if ($quantite <= 0) {
        return false; 
    }

    // requête SQL colonne "quantite"
    $stmt = $conn->prepare("SELECT quantite FROM Articles WHERE id_art = ?");
    if (!$stmt) {
        die("Erreur dans la préparation de la requête SQL : " . $conn->error);
    }

    
    $stmt->bind_param("i", $id_art);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        return false; //si article n'existe pas
    }

    $article = $result->fetch_assoc();
    $stockDisponible = (int)$article['quantite'];

    return $quantite <= $stockDisponible;
}

// Récupération identifiant article, quantité
if (isset($_POST['id_art']) && isset($_POST['quantite'])) {
    $id_art = (int)$_POST['id_art'];
    $quantite = (int)$_POST['quantite'];

    
    $conn = getBD();
    if (!$conn || $conn->connect_error) {
        die("Erreur de connexion à la base de données : " . $conn->connect_error);
    }

    //disponibilité vérif
    if (!verifierStockDisponible($id_art, $quantite, $conn)) {
        $error_message = "Quantité invalide ou stock insuffisant.";
        include 'error_template.php';
        exit();

    }

    // Vérifier variable session
    if (!isset($_SESSION['panier'])) {
        $_SESSION['panier'] = [];
    }

    // Ajouter/mettre à jour
    $trouve = false;
    foreach ($_SESSION['panier'] as &$article) {
        if ($article['id'] == $id_art) {
            $article['quantite'] += $quantite;
            $trouve = true;
            break;
        }
    }

    if (!$trouve) {
        $_SESSION['panier'][] = [
            'id' => $id_art,
            'quantite' => $quantite
        ];
    }

    header("Location: index.php");
    exit();
} else {
    echo "Données invalides.";
    exit();
}
?>
