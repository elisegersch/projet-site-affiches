document.addEventListener("DOMContentLoaded", function () {
    const chatForm = document.getElementById("chat-form");
    const chatInput = document.getElementById("chat-input");
    const chatMessages = document.getElementById("chat-messages");
    const statusDiv = document.getElementById("message-status"); // Div pour afficher les statuts ou erreurs

    // Fonction pour rafraîchir les messages
    function refreshMessages() {
        fetch("load_messages.php")
            .then(response => {
                if (!response.ok) {
                    throw new Error("Erreur réseau : " + response.status);
                }
                return response.json();
            })
            .then(data => {
                chatMessages.innerHTML = ""; // Effacer les anciens messages
                if (data.error) {
                    console.error("Erreur côté serveur :", data.error);
                    return;
                }
                data.forEach(msg => {
                    const messageElement = document.createElement("div");
                    messageElement.textContent = `${msg.user} dit '${msg.message}'`;
                    chatMessages.appendChild(messageElement);
                });
            })
            .catch(error => console.error("Erreur lors du chargement des messages :", error));
    }

    // Vérification du message
    function analyseMessage(message) {
        return fetch("analyse_message.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ message: message })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error("Erreur réseau : " + response.status);
            }
            return response.json();
        });
    }

    // Envoi du message à send_message.php (AJAX)
    function sendMessage(message) {
        fetch("send_message.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ message: message })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error("Erreur réseau : " + response.status);
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                chatInput.value = ""; // Effacer l'input
                statusDiv.textContent = ""; // Nettoyer les anciens messages d'erreur
                refreshMessages(); // Rafraîchir les messages
            } else {
                statusDiv.style.color = "red";
                statusDiv.textContent = data.error || "Message non envoyé.";
            }
        })
        .catch(error => {
            console.error("Erreur lors de l'envoi du message :", error);
            statusDiv.style.color = "red";
            statusDiv.textContent = "Une erreur est survenue lors de l'envoi du message.";
        });
    }

    // envoi du formulaire
    chatForm.addEventListener("submit", function (e) {
        e.preventDefault(); // Empêche le rechargement de la page
        const message = chatInput.value.trim();

        if (message.length > 0 && message.length <= 256) {
            analyseMessage(message)
                .then(data => {
                    if (data.status === "success") {
            
                        sendMessage(message);
                    } else {
                        statusDiv.style.color = "red";
                        statusDiv.textContent = "Message offensant détecté. Veuillez reformuler.";
                    }
                })
                .catch(error => {
                    console.error("Erreur lors de l'analyse du message :", error);
                    statusDiv.style.color = "red";
                    statusDiv.textContent = "Impossible d'analyser le message.";
                });
        } else {
            statusDiv.style.color = "red";
            statusDiv.textContent = "Votre message doit contenir entre 1 et 256 caractères.";
        }
    });

    // Rafraîchir les messages toutes les 5 secondes
    setInterval(refreshMessages, 5000);

    // Charger les messages au démarrage
    refreshMessages();
});
