<?php
include 'bd.php';

try {
    $conn = getBD();

    // Supprimer les messages +10 minutes
    $sql = "DELETE FROM messages WHERE created_at < (NOW() - INTERVAL 10 MINUTE)";
    if ($conn->query($sql) === TRUE) {
        echo "Messages supprimés avec succès.";
    } else {
        echo "Erreur lors de la suppression des messages : " . $conn->error;
    }

    
    $conn->close();
} catch (Exception $e) {
    echo "Erreur : " . $e->getMessage();
}
?>
