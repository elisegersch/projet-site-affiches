<?php
session_start();
require_once('bd.php');

// Récupération données formulaire
$mail = isset($_POST['mail']) ? htmlspecialchars($_POST['mail']) : '';
$motDePasse = isset($_POST['mdp']) ? $_POST['mdp'] : '';


if (!empty($mail) && !empty($motDePasse)) {
    try {
        $bd = getBD();
        $sql = "SELECT * FROM Clients WHERE mail = ?";
        $stmt = $bd->prepare($sql);
        $stmt->bind_param("s", $mail);
        $stmt->execute();
        $resultat = $stmt->get_result();

        if ($resultat->num_rows > 0) {
            $client = $resultat->fetch_assoc();

            // Vérification mdp
            if (password_verify($motDePasse, $client['mdp'])) {
                // Création session
                $_SESSION['client'] = array(
                    'id_client' => $client['id_client'],
                    'nom' => $client['nom'],
                    'prenom' => $client['prenom'],
                    'adresse' => $client['adresse'],
                    'numero' => $client['numero'],
                    'mail' => $client['mail'],
                    'ID_STRIPE' => $client['ID_STRIPE']

                );

                echo "success"; 
            } else {
                echo "Mot de passe incorrect."; 
            }
        } else {
            echo "Aucun compte trouvé pour cette adresse e-mail."; 
        }

    } catch (Exception $e) {
        echo "Erreur lors de la connexion : " . $e->getMessage(); 
    }
} else {
    echo "Veuillez remplir tous les champs."; 
}
?>
