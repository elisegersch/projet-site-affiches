<?php
include 'bd.php'; //connexion bd

$response = ['success' => false, 'message' => 'Une erreur est survenue.'];

$nom = $_POST['n'] ?? '';
$prenom = $_POST['p'] ?? '';
$adresse = $_POST['adr'] ?? '';
$numero = $_POST['num'] ?? '';
$email = $_POST['mail'] ?? '';
$mdp = $_POST['mdp1'] ?? '';

// Validation données
if (!empty($email) && filter_var($email, FILTER_VALIDATE_EMAIL)) {
    // Insérer dans bd
    $query = "INSERT INTO clients (nom, prenom, adresse, numero, mail, mdp) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $pdo->prepare($query);
    if ($stmt->execute([$nom, $prenom, $adresse, $numero, $email, password_hash($mdp, PASSWORD_DEFAULT)])) {
        $response['success'] = true;
        $response['message'] = 'Compte créé avec succès.';
    } else {
        $response['message'] = 'Impossible de créer le compte.';
    }
} else {
    $response['message'] = 'Adresse email invalide.';
}

echo json_encode($response);
?>
