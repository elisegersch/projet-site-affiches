<?php
// Charger librairie Stripe --> Composer
require_once('vendor/autoload.php');

// clé secrète
$stripe = new \Stripe\StripeClient('sk_test_51QQTtpFLEp7LcVBLmF4LEXQoB6kJKM7SVaV1uxEUxmmGaP8JJyLdBCdzAlvmJrXKPCGpeSNJIsUEXPBWKYrCb4Pp00TbOM6Ix5');

?>
