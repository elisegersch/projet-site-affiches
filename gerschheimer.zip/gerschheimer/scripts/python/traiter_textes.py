import os
import csv
import math
import json

# Chemins des fichiers
folder_path = "../textes/all_files"  # contient les textes
annotations_file = "../textes/annotations_metadata.csv"  # annotations hate ou nohate

# Étape 1 – Chargement des textes et labels
def charger_textes_et_labels():
    texts = []
    labels = []
    
    # Lecture fichier CSV
    with open(annotations_file, "r", encoding="utf-8") as csv_file:
        reader = csv.DictReader(csv_file)
        
        for row in reader:
            file_id = row["file_id"]
            label = row["label"]
            file_path = os.path.join(folder_path, f"{file_id}.txt")
            
            try:
                # Lecture fichier texte
                with open(file_path, "r", encoding="utf-8") as file:
                    texts.append(file.read().strip())
                    labels.append(label)
            except FileNotFoundError:
                print(f"Fichier {file_id}.txt introuvable, passage au suivant.")
    
    return texts, labels

# Étape 2 – Calcul de l'IDF
def calculer_idf(texts):
    word_document_count = {} 
    total_documents = len(texts)
    
    for text in texts:
        words = set(text.split())  
        for word in words:
            if word not in word_document_count:
                word_document_count[word] = 0
            word_document_count[word] += 1

    # Calcul de l'IDF pour chaque mot
    idf = {word: math.log(total_documents / count) for word, count in word_document_count.items()}
    return idf

# Étape 3 – Calcul du ScoreMap (TF-IDF ajusté par label)
def calculer_scoremap(texts, labels, idf):
    score_map = {}

    for text, label in zip(texts, labels):
        words = text.split()
        word_counts = {}
        
        # Calculer le TF (fréquence des mots dans le texte)
        for word in words:
            if word not in word_counts:
                word_counts[word] = 0
            word_counts[word] += 1
        
        for word, tf in word_counts.items():
            tf_idf = (tf / len(words)) * idf.get(word, 0)  # Calculer TF-IDF
            
            if word not in score_map:
                score_map[word] = 0
            
            # Ajuster en fonction du label
            if label == "hate":
                score_map[word] -= tf_idf
            else:
                score_map[word] += tf_idf

    return score_map

# Étape 4 – Classifier une phrase
def classifier_phrase(phrase, score_map):
    words = phrase.split()
    score_total = 0
    
    for word in words:
        score_total += score_map.get(word, 0)  # 0 si mot pas présent dans ScoreMap
    
    if score_total > 0:
        return "noHate"
    else:
        return "hate"

# Étape 4 – Sauvegarder ScoreMap
def sauvegarder_scoremap(score_map, fichier_json="score_map.json"):
    with open(fichier_json, "w", encoding="utf-8") as json_file:
        json.dump(score_map, json_file, ensure_ascii=False, indent=4)
    print(f"ScoreMap sauvegardé dans le fichier : {fichier_json}")


if __name__ == "__main__":
    # Charger textes+labels
    texts, labels = charger_textes_et_labels()
    print(f"Nombre de textes : {len(texts)}")
    if texts:
        print(f"Exemple de texte : {texts[0]}")
        print(f"Labels correspondants : {labels[:5]}")
    
    # Calculer l'IDF
    idf = calculer_idf(texts)
    print("\nExemple d'IDF calculés :")
    for word, value in list(idf.items())[:10]:  # Afficher les 10 premiers mots
        print(f"{word}: {value:.4f}")
    
    # Calculer ScoreMap
    score_map = calculer_scoremap(texts, labels, idf)
    print("\nExemple de scores TF-IDF dans ScoreMap :")
    for word, value in list(score_map.items())[:10]:  # Afficher les 10 premiers scores
        print(f"{word}: {value:.4f}")
    
    
    sauvegarder_scoremap(score_map)

    # Tester la classification d'une phrase
    phrase_test = "This is an example of a hate speech."
    resultat = classifier_phrase(phrase_test, score_map)
    print(f"\nPhrase : {phrase_test}")
    print(f"Résultat : {resultat}")
