<?php
session_start();
require_once 'bd.php';

// Vérif connexion
if (!isset($_SESSION['client'])) {
    echo '<meta http-equiv="refresh" content="0;URL=connexion.php">';
    exit();
}

// Générer token
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}


$panier = isset($_SESSION['panier']) ? $_SESSION['panier'] : [];

// Si le panier vide
if (empty($panier)) {
    header("Location: panier.php");
    exit();
}

// infos client
$nom = htmlspecialchars($_SESSION['client']['nom']);
$prenom = htmlspecialchars($_SESSION['client']['prenom']);
$adresse = htmlspecialchars($_SESSION['client']['adresse']);

// données Stripe
$conn = getBD();
$line_items = [];
$total_commande = 0;

foreach ($panier as $item) {
    $id_art = (int)$item['id'];
    $quantite = (int)$item['quantite'];

    // Recherche article dans bd
    $stmt = $conn->prepare("SELECT ID_STRIPE, nom, prix FROM Articles WHERE id_art = ?");
    $stmt->bind_param("i", $id_art);
    $stmt->execute();
    $resultat = $stmt->get_result();
    $article = $resultat->fetch_assoc();

    if (!$article) {
        echo "Erreur : Article introuvable.";
        exit();
    }

    // Ajouter à liste pour Stripe
    $line_items[] = [
        'price' => $article['ID_STRIPE'], // ID Stripe produit
        'quantity' => $quantite,          
    ];

    $prix_total = $article['prix'] * $quantite;
    $total_commande += $prix_total;
}

// Stocker données Stripe
$_SESSION['line_items'] = $line_items;
$_SESSION['customer_id'] = $_SESSION['client']['ID_STRIPE']; // ID Stripe du client
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <link rel="stylesheet" href="styles/styles.css" type="text/css" media="screen" />
    <meta charset="UTF-8">
    <title>Commande - l'Afficherie</title>
</head>
<body>
    <header>
        <h1>Récapitulatif de votre commande</h1>
    </header>

    <main>
    <table border="1">
        <tr>
            <th>Article</th>
            <th>Quantité</th>
            <th>Prix</th>
        </tr>
        <?php foreach ($panier as $item): ?>
            <?php
                $id_art = (int)$item['id'];
                $quantite = (int)$item['quantite'];

                // Recherche article dans la base de données
                $stmt = $conn->prepare("SELECT nom, prix FROM Articles WHERE id_art = ?");
                $stmt->bind_param("i", $id_art);
                $stmt->execute();
                $resultat = $stmt->get_result();
                $article = $resultat->fetch_assoc();

                if (!$article) {
                    echo "Erreur : Article introuvable.";
                    exit();
                }

                $prix_total = $article['prix'] * $quantite;
            ?>
            <tr>
                <td><?php echo htmlspecialchars($article['nom']); ?></td>
                <td><?php echo htmlspecialchars($quantite); ?></td>
                <td><?php echo htmlspecialchars($prix_total); ?> €</td>
            </tr>
        <?php endforeach; ?>
        <tr>
            <td colspan="2"><strong>Total de la commande :</strong></td>
            <td><?php echo htmlspecialchars($total_commande); ?> €</td>
        </tr>
    </table>


        <p>La commande sera expédiée à l’adresse suivante :</p>
        <p><?php echo $nom . ' ' . $prenom; ?><br><?php echo $adresse; ?></p>
        
        <!-- Formulaire redirigeant vers paiement.php -->
        <form action="paiement.php" method="POST">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token']; ?>">
            <button type="submit">Payer avec Stripe</button>
        </form>
    
        <a href="index.php">Retour à l'accueil</a>
    </main>

    <footer>
        <p>&copy; 2024 L'Afficherie</p>
    </footer>
</body>
</html>
