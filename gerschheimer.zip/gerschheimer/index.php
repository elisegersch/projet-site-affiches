<?php
session_start();
require_once 'bd.php';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <link rel="stylesheet" href="styles/styles.css" >
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>l'Afficherie - Magasin d'affiches</title>
</head>
<body>
    <header>
        <h1>L'Afficherie</h1>
        <p>Bienvenue dans votre magasin d'affiches !</p>
        <div class="user-links">
        <?php
        // Vérif connexion
        if (!isset($_SESSION['client'])) {
            // Si aucune session client, afficher "Nouveau Client" et "Se connecter"
            echo '<a href="nouveau.php">Nouveau Client</a> ';
            echo '<a href="connexion.php">Se connecter</a>';
        } else {
            // Si l'utilisateur est connecté, afficher "Bonjour Prénom Nom"
            $prenom = htmlspecialchars($_SESSION['client']['prenom']);
            $nom = htmlspecialchars($_SESSION['client']['nom']);
            echo "Bonjour $prenom $nom";
            echo '<a href="panier.php">Voir mon panier</a> ';
            echo '<a href="historique.php">Historique des commandes</a> '; // Lien vers historique.php
            echo '<a href="deconnexion.php">Se déconnecter</a>';
        }
        ?>
        </div>
    </header>

    <main>
        <h2>Nos articles</h2>
        <table>
            <thead>
                <tr>
                    <th>Numéro d'identifiant</th>
                    <th>Nom de l'article</th>
                    <th>Quantité en stock</th>
                    <th>Prix</th>
                </tr>
            </thead>
            <?php
            try {
                $bd=getBD();
                $sql = "SELECT id_art, nom, quantite, prix FROM Articles";
                $resultat = $bd->query($sql);

                if ($resultat->num_rows > 0) {
                    while ($ligne = $resultat->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($ligne["id_art"]) . "</td>";
                        echo "<td><a href='articles/article.php?id_art=" . htmlspecialchars($ligne["id_art"]) . "'>" . htmlspecialchars($ligne["nom"]) . "</a></td>";
                        echo "<td>" . htmlspecialchars($ligne["quantite"]) . "</td>";
                        echo "<td>" . htmlspecialchars($ligne["prix"]) . "€</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='4'>Aucun article disponible</td></tr>";
                }
            } catch (Exception $e) {
                echo "Une erreur s'est produite : " . $e->getMessage();
            }
            ?>
        </table>
    </main>

    <!-- Fenêtre de chat -->
    <?php if (isset($_SESSION['client'])): ?>
        <div class="chat-container">
            <div class="chat-header">Discussion</div>
            <div class="chat-messages" id="chat-messages"></div>
            <form id="chat-form" class="chat-form">
                <input 
                    type="text" 
                    id="chat-input" 
                    class="chat-input" 
                    placeholder="Écris ton message..." 
                    maxlength="256" 
                />
                <button type="submit" class="chat-submit">Envoyer</button>
            </form>
            <div id="message-status"></div> 
        </div>
    <?php endif; ?>

    <footer>
        <p><a href="contact/contact.html">Contact</a></p>
    </footer>

    <!-- Inclusion du script pour le chat -->
    <script src="scripts/chat.js"></script>
</body>
</html>
