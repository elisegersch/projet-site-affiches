<?php
session_start();
require_once 'bd.php'; 

// Vérif connexion
if (!isset($_SESSION['client'])) {
    header("Location: connexion.php");
    exit();
}


// Récupération panier
$panier = isset($_SESSION['panier']) ? $_SESSION['panier'] : [];

// Si panier est vide, affiche un message
if (empty($panier)) {
    $message_panier_vide = "Votre panier ne contient aucun article.";
} else {
    $articles_panier = [];
    $total_commande = 0;

    try {
        // Connexion bd
        $conn = getBD();

        // afficher chaque article
        foreach ($panier as $item) {
            $id_art = (int)$item['id'];
            $quantite = (int)$item['quantite'];

            // Récupérer infos de l'article 
            $stmt = $conn->prepare("SELECT nom, prix FROM Articles WHERE id_art = ?");
            $stmt->bind_param("i", $id_art);
            $stmt->execute();
            $resultat = $stmt->get_result();

            if ($resultat && $resultat->num_rows > 0) {
                $article = $resultat->fetch_assoc();

                // Calcul prix total pour cet article
                $prix_total = $article['prix'] * $quantite;
                $total_commande += $prix_total;

                // Ajouter à la liste des articles à afficher
                $articles_panier[] = [
                    'id' => htmlspecialchars($id_art),
                    'nom' => htmlspecialchars($article['nom']),
                    'prix' => htmlspecialchars($article['prix']),
                    'quantite' => htmlspecialchars($quantite),
                    'prix_total' => htmlspecialchars($prix_total)
                ];
            }

            $stmt->close();
        }

        $conn->close();

    } catch (Exception $e) {
        echo "Une erreur s'est produite : " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <link rel="stylesheet" href="styles/styles.css" type="text/css" media="screen" />
    <meta charset="UTF-8">
    <title>Mon Panier - l'Afficherie</title>
</head>
<body>
    <header>
        <h1>Votre Panier</h1>
    </header>

    <main>
        <?php if (isset($message_panier_vide)): ?>
            <p><?php echo $message_panier_vide; ?></p>
        <?php else: ?>
            <table>
                <tr><th>ID Article</th><th>Nom</th><th>Prix Unitaire</th><th>Quantité</th><th>Prix Total</th></tr>
                <?php foreach ($articles_panier as $article): ?>
                    <tr>
                        <td><?php echo $article['id']; ?></td>
                        <td><?php echo $article['nom']; ?></td>
                        <td><?php echo $article['prix']; ?> €</td>
                        <td><?php echo $article['quantite']; ?></td>
                        <td><?php echo $article['prix_total']; ?> €</td>
                    </tr>
                <?php endforeach; ?>
                <tr>
                    <td colspan="4"><strong>Total de la commande :</strong></td>
                    <td><?php echo htmlspecialchars($total_commande); ?> €</td>
                </tr>
            </table>
            <!-- Ajout du lien vers la page commande.php ici -->
            <form method="POST" action="commande.php">
                <button type="submit">Passer la commande</button>
            </form>
        <?php endif; ?>
    </main>

    <footer>
        <p><a href="index.php">Retour</a></p>
    </footer>
</body>
</html>
