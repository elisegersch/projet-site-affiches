<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

function getBD() {
    $serveur = "localhost";
    $utilisateur = "root";
    $mot_de_passe = "root";
    $nom_base_de_donnees = "l'Afficherie";

    $connexion = new mysqli($serveur, $utilisateur, $mot_de_passe, $nom_base_de_donnees);


    if ($connexion->connect_error) {
        throw new Exception("la connexion à la base de donée à échouée : " . $connexion->connect_error);
    }

    return $connexion;
}
?>