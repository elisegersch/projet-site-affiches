<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles/styles.css" type="text/css">
    <title>Erreur - L'Afficherie</title>
</head>
<body>
    <header>
        <h1>Une erreur s'est produite</h1>
    </header>

    <main>
        <div class="error-container">
            <h1>Erreur</h1>
            <p><?= htmlspecialchars($error_message); ?></p>
            <a href="index.php">Retour à l'accueil</a>
        </div>
    </main>

    <footer>
        <p>&copy; 2024 L'Afficherie</p>
    </footer>
</body>
</html>
