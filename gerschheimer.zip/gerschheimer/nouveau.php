<?php
session_start();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <link rel="stylesheet" href="styles/styles.css" type="text/css" media="screen" />
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nouveau Client - L'Afficherie</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
    $(document).ready(function () {
        var checkInput = function (input, isValid, errorMessage = '') {
            if (isValid) {
                input.css('background-color', '#ccffcc'); // vert si valide
                input.next('.error').remove(); 
            } else {
                input.css('background-color', '#ffcccc'); // Rouge si non valide
                if (input.next('.error').length === 0) { 
                    input.after('<span class="error" style="color: red;">' + errorMessage + '</span>');
                }
            }
        };

        // Vérification AJAX de l'email
        $("#mail").on("blur", function () {
            var email = $(this).val();
            if (email !== "") {
                $.ajax({
                    url: "verification_email.php",
                    method: "POST",
                    data: { email: email },
                    dataType: "json",
                    success: function (response) {
                        if (response.status === "exists") {
                            checkInput($("#mail"), false, response.message);
                            $("#ajaxSubmitButton").prop("disabled", true); // Désactiver le bouton d'envoi
                        } else if (response.status === "available") {
                            checkInput($("#mail"), true);
                            $("#ajaxSubmitButton").prop("disabled", false); // Activer le bouton d'envoi
                        } else {
                            checkInput($("#mail"), false, "Erreur de vérification.");
                        }
                    },
                    error: function () {
                        checkInput($("#mail"), false, "Impossible de vérifier l'email.");
                    }
                });
            }
        });

        // Validation des champs
        $('input[required]').on('input', function () {
            var field = $(this);
            var value = field.val().trim();
            var isValid = true;
            var errorMessage = '';

            if (field.attr('id') === 'mail') {
                isValid = /^[^@]+@[^@]+\.[^@]+$/.test(value);
                errorMessage = 'Entrez une adresse e-mail valide.';
            } else if (field.attr('id') === 'num') {
                isValid = /^\d{10}$/.test(value);
                errorMessage = 'Le numéro de téléphone doit contenir exactement 10 chiffres.';
            } else if (field.attr('id') === 'mdp1') {
                isValid = /^(?=.*\d)(?=.*[a-z])(?=.*\W).*$/.test(value);
                errorMessage = 'Le mot de passe doit contenir au moins 1 lettre, 1 chiffre et un caractère spécial.';
            } else if (field.attr('id') === 'mdp2') {
                isValid = (value === $('#mdp1').val());
                errorMessage = 'Les mots de passe ne correspondent pas.';
            } else {
                isValid = value.length > 0;
                errorMessage = 'Ce champ est requis.';
            }
            checkInput(field, isValid, errorMessage);
        });

        // Soumission AJAX
        $("#ajaxSubmitButton").click(function (event) {
            event.preventDefault(); // Empêche comportement par défaut

            // Vérification des champs avant soumission
            var formValid = true;
            $('input[required]').each(function () {
                var input = $(this);
                input.trigger('input'); 
                if (input.css('background-color') === 'rgb(255, 204, 204)') {
                    formValid = false;
                }
            });

            if (!formValid) {
                alert("Veuillez corriger les erreurs avant d'envoyer le formulaire.");
                return;
            }

            // Récupérer données du formulaire
            var formData = {
                n: $("#n").val(),
                p: $("#p").val(),
                adr: $("#adr").val(),
                num: $("#num").val(),
                mail: $("#mail").val(),
                mdp1: $("#mdp1").val(),
                mdp2: $("#mdp2").val()
            };

            // Soumission AJAX
            $.ajax({
                url: "enregistrement.php",
                method: "POST",
                data: formData,
                dataType: "json",
                success: function (response) {
                    if (response.success) {
                        alert(response.message);
                        $("form")[0].reset(); // Réinitialise le formulaire
                    } else {
                        alert("Erreur : " + response.message);
                    }
                },
                error: function () {
                    alert("Une erreur est survenue lors de la soumission du formulaire.");
                }
            });
        });
    });
    </script>
</head>
<body>
    <header>
        <h1>Nouveau Client</h1>
    </header>

    <main>
        <form>
            <label for="n">Nom :</label>
            <input type="text" id="n" name="n" required><br><br>

            <label for="p">Prénom :</label>
            <input type="text" id="p" name="p" required><br><br>

            <label for="adr">Adresse :</label>
            <input type="text" id="adr" name="adr" required><br><br>

            <label for="num">Numéro de téléphone :</label>
            <input type="text" id="num" name="num" required><br><br>

            <label for="mail">Adresse e-mail :</label>
            <input type="email" id="mail" name="mail" required>
            <br><br>

            <label for="mdp1">Mot de passe :</label>
            <input type="password" id="mdp1" name="mdp1" required><br><br>

            <label for="mdp2">Confirmer votre mot de passe :</label>
            <input type="password" id="mdp2" name="mdp2" required><br><br>

            <input type="button" id="ajaxSubmitButton" value="Enregistrer">
        </form>
    </main>

    <footer>
        <p><a href="index.php">Retour</a></p>
    </footer>
</body>
</html>
