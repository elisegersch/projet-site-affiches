<?php
session_start();
require_once 'bd.php'; // Connexion bd

// vérification connexion
if (!isset($_SESSION['client'])) {
    header("Location: connexion.php");
    exit();
}

// Récupération données panier
$panier = isset($_SESSION['panier']) ? $_SESSION['panier'] : [];

// Vérification si le panier n'est pas vide
if (empty($panier)) {
    echo "Votre panier est vide.";
    echo '<p><a href="index.php">Retour à l\'accueil</a></p>';
    exit();
}

// Récupération ID client
$id_client = $_SESSION['client']['id_client'];

try {
    // Connexion bd
    $conn = getBD();

    // Démarrer transaction (cohérence des données)
    $conn->begin_transaction();

    foreach ($panier as $item) {
        $id_art = (int)$item['id'];
        $quantite = (int)$item['quantite'];

        // Vérifier si stock suffisant
        $stmt_check = $conn->prepare("SELECT quantite FROM Articles WHERE id_art = ?");
        $stmt_check->bind_param("i", $id_art);
        $stmt_check->execute();
        $result_check = $stmt_check->get_result();
        $article = $result_check->fetch_assoc();
        $stmt_check->close();

        if (!$article) {
            throw new Exception("L'article avec l'ID $id_art n'existe pas.");
        }

        if ($article['quantite'] < $quantite) {
            throw new Exception("Stock insuffisant pour l'article avec l'ID $id_art. Stock disponible : {$article['quantite']}, demandé : $quantite.");
        }

        // Insérer article dans table Commandes
        $stmt = $conn->prepare("INSERT INTO Commandes (id_art, id_client, quantite, envoi) VALUES (?, ?, ?, FALSE)");
        $stmt->bind_param("iii", $id_art, $id_client, $quantite);
        $stmt->execute();
        $stmt->close();

        // Mettre à jour quantité 
        $stmt_update = $conn->prepare("UPDATE Articles SET quantite = quantite - ? WHERE id_art = ?");
        $stmt_update->bind_param("ii", $quantite, $id_art);
        $stmt_update->execute();
        $stmt_update->close();
    }

    // valider transaction
    $conn->commit();

    // Vider panier 
    unset($_SESSION['panier']);
    unset($_SESSION['line_items']);

    // Fermeture connexion
    $conn->close();

} catch (Exception $e) {
    //si erreur
    if (isset($conn) && $conn->connect_errno === 0) {
        $conn->rollback();
    }

    
    echo "Une erreur s'est produite : " . $e->getMessage();
    echo '<p><a href="panier.php">Retour au panier</a></p>';
    exit();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles/styles.css" type="text/css">
    <title>Confirmation de commande</title>
</head>
<body>
    <header>
        <h1>Confirmation de commande</h1>
    </header>

    <main>
        <div class="confirmation-container">
            <h2>Votre commande a bien été enregistrée !</h2>
            <p>Merci pour votre achat. Nous traiterons votre commande dans les plus brefs délais.</p>
            <a href="index.php" class="btn">Retour à l'accueil</a>
        </div>
    </main>

    <footer>
        <p>&copy; 2024 L'Afficherie </p>
    </footer>
</body>
</html>
