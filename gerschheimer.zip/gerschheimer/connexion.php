<!DOCTYPE html>
<html lang="fr">
<head>
    <link rel="stylesheet" href="styles/styles.css" type="text/css" media="screen" />
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
    $(document).ready(function() {
        $('form').submit(function(event) {
            event.preventDefault(); // Empêche soumission standard du formulaire
            var email = $('#mail').val();
            var password = $('#mdp').val();

            $.ajax({
                type: 'POST',
                url: 'connecter.php', //gère connexion
                data: { mail: email, mdp: password },
                success: function(response) {
                    if (response === 'success') {
                        window.location.href = 'index.php'; // Redirection vers la page d'accueil si succès
                    } else {
                        alert(response); 
                    }
                },
                error: function() {
                    alert('Erreur de connexion au serveur.'); // Gestion d'erreur si requête AJAX échoue
                }
            });
        });
    });
    </script>
</head>
<body class="login-page">
    <div class="form-wrapper">
        <div class="container">
            <!-- Formulaire de connexion -->
            <form id="loginForm">
                <label for="mail">Adresse e-mail :</label>
                <input type="email" id="mail" name="mail" required><br><br>
        
                <label for="mdp">Mot de passe :</label>
                <input type="password" id="mdp" name="mdp" required><br><br>

                <button type="submit">Se connecter</button>
            </form>
        </div>
    </div>
    <!-- Lien vers la page de création de compte -->
    <p>Vous n'avez pas encore de compte ? <a href="nouveau.php">Créer un compte</a></p>

    <!-- Lien pour retourner à l'accueil -->
    <footer>
        <p><a href="index.php">Retour</a></p>
    </footer>
</body>
</html>
