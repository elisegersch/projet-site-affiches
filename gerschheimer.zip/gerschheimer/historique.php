<?php
session_start();
require_once 'bd.php';

// Vérif connexion
if (!isset($_SESSION['client'])) {
    header("Location: connexion.php");
    exit();
}

// Récupération ID client
$id_client = $_SESSION['client']['id_client'];

try {
    $conn = getBD();

    //récupérer l'historique des commandes du client
    $stmt = $conn->prepare("
        SELECT c.id_commande, c.id_art, a.nom, a.prix, c.quantite, c.envoi
        FROM Commandes c
        JOIN Articles a ON c.id_art = a.id_art
        WHERE c.id_client = ?
    ");
    $stmt->bind_param("i", $id_client);
    $stmt->execute();
    $resultat = $stmt->get_result();

    // Vérification si client a des commandes
    if ($resultat->num_rows > 0) {
        $commandes = $resultat->fetch_all(MYSQLI_ASSOC);
    } else {
        $message = "Vous n'avez passé aucune commande.";
    }

    // Fermeture connexion
    $stmt->close();
    $conn->close();

} catch (Exception $e) {
    echo "Une erreur s'est produite : " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <link rel="stylesheet" href="styles/styles.css" type="text/css" media="screen" />
    <meta charset="UTF-8">
    <title>Historique des commandes - l'Afficherie</title>
</head>
<body>
    <header>
        <h1>Historique de vos commandes</h1>
    </header>

    <main>
        <?php if (isset($message)): ?>
            <p><?php echo $message; ?></p>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>ID Commande</th>
                        <th>ID Article</th>
                        <th>Nom de l'article</th>
                        <th>Prix</th>
                        <th>Quantité commandée</th>
                        <th>État de la commande</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($commandes as $commande): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($commande['id_commande']); ?></td>
                            <td><?php echo htmlspecialchars($commande['id_art']); ?></td>
                            <td><?php echo htmlspecialchars($commande['nom']); ?></td>
                            <td><?php echo htmlspecialchars($commande['prix']); ?> €</td>
                            <td><?php echo htmlspecialchars($commande['quantite']); ?></td>
                            <td><?php echo $commande['envoi'] ? "Envoyée" : "En attente d'envoi"; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </main>

    <footer>
        <p><a href="index.php">Retour à l'accueil</a></p>
    </footer>

</body>
</html>
