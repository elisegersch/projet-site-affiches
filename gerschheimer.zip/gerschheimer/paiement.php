<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once('vendor/autoload.php');
require_once('stripe.php');
require_once('bd.php');

if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    echo 'Invalid request';
    exit();
}

session_start();

// Vérif données dans session
if (!isset($_SESSION['customer_id']) || !isset($_SESSION['line_items'])) {
    $error_message = "Données manquantes pour le paiement.";
    include 'error_template.php';
    exit();
}

//connexion bd
$conn = getBD();

// Vérif du stock
foreach ($_SESSION['line_items'] as $item) {
    $stmt = $conn->prepare("SELECT quantite FROM Articles WHERE ID_STRIPE = ?");
    $stmt->bind_param("s", $item['price']);
    $stmt->execute();
    $result = $stmt->get_result();

    if (!$result || $result->num_rows === 0) {
        $error_message = "Erreur : Article introuvable.";
        include 'error_template.php';
        exit();
    }

    $article = $result->fetch_assoc();

    if ($article['quantite'] < $item['quantity']) {
        $error_message = "Erreur : Stock insuffisant pour l'article avec ID Stripe {$item['price']}. Disponible : {$article['quantite']}, demandé : {$item['quantity']}.";
        include 'error_template.php';
        exit();
    }
}

try {
    $checkout_session = $stripe->checkout->sessions->create([
        'customer' => $_SESSION['customer_id'],
        'success_url' => 'http://localhost:8888/gerschheimer/gerschheimer/acheter.php',
        'cancel_url' => 'http://localhost:8888/gerschheimer/cancel.php',
        'mode' => 'payment',
        'line_items' => $_SESSION['line_items'],
    ]);

    header("HTTP/1.1 303 See Other");
    header("Location: " . $checkout_session->url);
    exit();
} catch (Exception $e) {
    $error_message = 'Erreur Stripe : ' . $e->getMessage();
    include 'error_template.php';
    exit();
}
