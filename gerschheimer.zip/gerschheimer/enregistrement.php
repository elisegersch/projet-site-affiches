<?php
session_start();
require_once('bd.php'); 
require_once('stripe.php'); // Configuration Stripe

header('Content-Type: application/json');

// Récupération données du formulaire
$nom = htmlspecialchars($_POST['n'] ?? '');
$prenom = htmlspecialchars($_POST['p'] ?? '');
$adresse = htmlspecialchars($_POST['adr'] ?? '');
$numero = htmlspecialchars($_POST['num'] ?? '');
$mail = htmlspecialchars($_POST['mail'] ?? '');
$motDePasse = $_POST['mdp1'] ?? '';
$confirmMotDePasse = $_POST['mdp2'] ?? '';

// enregistrer infos dans bd
function enregistrer($nom, $prenom, $adresse, $numero, $mail, $motDePasse, $idStripe) {
    try {
        $bd = getBD();
        $stmt = $bd->prepare("INSERT INTO Clients (nom, prenom, adresse, numero, mail, mdp, ID_STRIPE) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $hashedPassword = password_hash($motDePasse, PASSWORD_DEFAULT);
        $stmt->bind_param("sssssss", $nom, $prenom, $adresse, $numero, $mail, $hashedPassword, $idStripe);
        if (!$stmt->execute()) {
            throw new Exception("Erreur pendant l'exécution de la requête : " . $stmt->error);
        }
    } catch (Exception $e) {
        throw new Exception("Erreur d'enregistrement : " . $e->getMessage());
    }
}

// valider le numéro de téléphone
function estNumeroValide($numero) {
    return preg_match("/^0[1-9][0-9]{8}$/", $numero);
}

// Validation des données
if (!empty($nom) && !empty($prenom) && !empty($adresse) && !empty($numero) && !empty($mail) && !empty($motDePasse) && $motDePasse === $confirmMotDePasse) {
    if (estNumeroValide($numero)) {
        try {
            // Étape 1 : Créer un client Stripe
            $stripeCustomer = $stripe->customers->create([
                'email' => $mail,
                'name' => "$prenom $nom",
                'address' => [
                    'line1' => $adresse,
                ],
                'phone' => $numero,
            ]);
            $idStripe = $stripeCustomer->id;

            // Étape 2 : Enregistrer dans la base de données
            enregistrer($nom, $prenom, $adresse, $numero, $mail, $motDePasse, $idStripe);

            echo json_encode(['success' => true, 'message' => "Enregistrement réussi!"]);
            exit;
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => "Erreur lors de la création du client : " . $e->getMessage()]);
            exit;
        }
    } else {
        echo json_encode(['success' => false, 'message' => "Le numéro de téléphone est invalide."]);
        exit;
    }
} else {
    echo json_encode(['success' => false, 'message' => "Veuillez remplir tous les champs et confirmer correctement le mot de passe."]);
    exit;
}
