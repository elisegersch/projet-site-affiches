<?php
session_start();
require_once '../bd.php'; 

// Génération du token

if (isset($_SESSION['client'])){
    if(!isset($_SESSION['csrf_token'])){
        $_SESSION['csrf_token']=bin2hex(random_bytes(32));
    }
    $csrf_token=$_SESSION['csrf_token'];
}


if (isset($_GET['id_art'])) {
    $id_art = (int)$_GET['id_art']; 

    try {

        // Récupération de la connexion à bd.php
        $conn = getBD();

        // Préparation requête pour éviter injections SQL
        $stmt = $conn->prepare("SELECT * FROM Articles WHERE id_art = ?");
        $stmt->bind_param("i", $id_art);
        $stmt->execute();
        $resultat = $stmt->get_result();

        // Vérification résultats
        if ($resultat && $resultat->num_rows > 0) {
            $article = $resultat->fetch_assoc();
        } else {
            echo "<p>Aucun article trouvé avec cet identifiant.</p>";
        }

        
        $stmt->close();
        $conn->close();

    } catch (Exception $e) {
        echo "Une erreur s'est produite : " . $e->getMessage();
    }
} else {
    echo "<p>Identifiant d'article non fourni.</p>";
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <link rel="stylesheet" href="../styles/styles.css" type="text/css" media="screen" />
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Article - l'Afficherie</title>
</head>
<body>
    
    <header>
        <h1><?php echo htmlspecialchars($article['nom']); ?></h1>
    </header>


    <main>
        <?php if (isset($article)) : ?>
            <img src="<?php echo '../'.htmlspecialchars($article['url_photo']); ?>" alt="Image de l'article" style="width:300px;">
            <p><strong>Description :</strong> <?php echo htmlspecialchars($article['description']); ?></p>
            <p><strong>Quantité en stock :</strong> <?php echo htmlspecialchars($article['quantite']); ?></p>
            <p><strong>Prix :</strong> <?php echo htmlspecialchars($article['prix']); ?> €</p>
            <?php if (isset($_SESSION['client'])) : ?>
                <!-- Formulaire d'ajout au panier pour les utilisateurs connectés -->
                <form action="../ajouter.php" method="POST">
                    <input type="hidden" name="id_art" value="<?php echo $id_art; ?>">
                    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token'] ; ?>">

                    <label for="quantite">Quantité :</label>
                    <input type="number" id="quantite" name="quantite" min="1" max="<?php echo htmlspecialchars($article['quantite']); ?>" value="1" required>
                    <input type="submit" value="Ajouter à votre panier">
                </form>
            <?php else : ?>
                <p><a href="../connexion.php">Connectez-vous</a> pour ajouter cet article à votre panier.</p>
            <?php endif; ?>
        <?php else: ?>
            <p>Aucun article trouvé avec cet identifiant.</p>
        <?php endif; ?>
    </main>

    <footer>
        <p><a href="../index.php">Retour</a></p>
    </footer>

</body>
</html>
