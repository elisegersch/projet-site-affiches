<?php
session_start();
require_once 'bd.php';

header('Content-Type: application/json');
//verif connexion
if (!isset($_SESSION['client'])) {
    echo json_encode(['success' => false, 'error' => 'Utilisateur non connecté.']);
    exit;
}

// Récupérer données envoyées
$data = json_decode(file_get_contents('php://input'), true);
$message = trim($data['message'] ?? '');

if (strlen($message) === 0 || strlen($message) > 256) {
    echo json_encode(['success' => false, 'error' => 'Le message doit contenir entre 1 et 256 caractères.']);
    exit;
}

try {
    $bd = getBD();
    $user_id = $_SESSION['client']['id_client']; 

    $stmt = $bd->prepare('INSERT INTO Messages (user_id, message, created_at) VALUES (?, ?, NOW())');
    $stmt->bind_param('is', $user_id, $message);

    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Erreur lors de l\'insertion du message.']);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>
