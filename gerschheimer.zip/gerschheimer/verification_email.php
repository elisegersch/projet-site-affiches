<?php
require_once('bd.php');

// réponse JSON
header('Content-Type: application/json');
$response = ['status' => 'error', 'message' => 'Invalid request'];

if (isset($_POST['email'])) {
    $email = htmlspecialchars($_POST['email']);
    try {
        $connexion = getBD();
        $stmt = $connexion->prepare("SELECT COUNT(*) FROM Clients WHERE mail = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->bind_result($count);
        $stmt->fetch();

        if ($count > 0) {
            $response = ['status' => 'exists', 'message' => 'Cette adresse email est déjà utilisée.'];
        } else {
            $response = ['status' => 'available', 'message' => 'Cette adresse email est disponible.'];
        }
    } catch (Exception $e) {
        $response = ['status' => 'error', 'message' => 'Erreur lors de la vérification de l\'email.'];
    }
} else {
    $response = ['status' => 'error', 'message' => 'Paramètre email manquant.'];
}

echo json_encode($response);
?>
